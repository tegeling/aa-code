({
  helperMethod: function () {}
});
