({
  helperMethod: function () {}
});